package entity;

import adt.DoneeInterface;

public class DoneeFood {
    private String DoneeFoodInfo;
    private DoneeInterface<Donee> donees;
    
    public DoneeFood(String DoneeFoodInfo){
        this.DoneeFoodInfo = DoneeFoodInfo;
    }
    
    public DoneeInterface<Donee> getDonee(){
        return donees;
    }
    
    public void setDonees(DoneeInterface<Donee> donee){
        this.donees = donees;
    }
    
    public String getDoneeFoodInfo(){
        return DoneeFoodInfo;
    }
    
    public void setDoneeFoodInfo(String DoneeFoodInfo){
        this.DoneeFoodInfo = DoneeFoodInfo;
    }
    
    public String toString(){
        return "DoneeFood[Donee & Food Info : " +DoneeFoodInfo+ "/n doneed : " +donees+" ]";
    }
}
