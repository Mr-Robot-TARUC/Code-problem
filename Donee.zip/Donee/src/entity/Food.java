package entity;

public class Food extends Donee{
    private String foodName;
    private String foodQty;

    public Food(int Id, String doneeName, String foodName, String foodQty){
    super(Id,doneeName);
    this.foodName = foodName;
    this.foodQty = foodQty;
}
    //set and get
    public String getfoodName(){
        return foodName;
    }
    
    public void setfoodName(String foodName){
        this.foodName = foodName;
    }
    
    public String getfoodQty(){
        return foodQty;
    }
    
    public void setfoodQty(String foodQty){
        this.foodQty = foodQty;
    }

    public String toString(){
    return super.toString()+"\nFood Name :" +foodName+"Food Quantity :"+foodQty;
    }
}