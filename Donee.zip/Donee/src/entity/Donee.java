package entity;

public class Donee implements Comparable<Donee>{

    protected int Id;
    protected String doneeName;

       public Donee(int Id, String doneeName){
        this.Id = Id;
        this.doneeName = doneeName;
    }
       
       //get and set
       public int getId(){
           return Id;
       }
       
       public void setId(int Id){
           this.Id = Id;
       }
       
       public String getdoneeName(){
           return doneeName;
       }
       
       public void setdoneeName(String doneeName){
           this.doneeName = doneeName;
       }

    public String toString(){
        return "|| ID    ||"+Id+ " || Donee Name  ||"+doneeName;
    }

    @Override
    public int compareTo(Donee donee) {
        return this.Id - donee.getId();
    }
    
}

    


