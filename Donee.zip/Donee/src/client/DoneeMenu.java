package client;

import adt.LinkQueue;
import entity.DoneeFood;
import module.DoneeManagement;
import util.KeyboardInput;

public class DoneeMenu {

    private DoneeFood df;
    
    public static void main(String[] args) {
        DoneeMenu menu = new DoneeMenu();
         menu.initializeDonee();
        
        System.out.println("=============================");
        System.out.println("===== DONEE INFORMATION =====");
        
        menu.displayMainMenu();
        
        System.out.println("----- BACK TO MAIN PAGE -----");
    }

   private void initializeDonee() {
          df = new DoneeFood("Our Donee & Food");
          df.setDonees(new LinkQueue<>());
          
          DoneeManagement.loadDoneeData(df.getDonee());    
    }
    
    private void displayMainMenu(){
        String menuOption = "";
        
        do{
            System.out.println("=============================");
            System.out.println("=== 1. Donee Managament   ===");
            System.out.println("=== 99. Exit              ===");
            System.out.println("=============================");
            
            System.out.print("Option: ");
            menuOption = KeyboardInput.getInputFromUser();
            System.out.println();
            
            mainMenuAction(menuOption);  
        } while (!menuOption.equals("99"));
    }
    
    private void mainMenuAction(String menuOption) {
		switch (menuOption) {
		case "1":
			displayDoneeManagementMenu();
			System.out.println();
			break;
		case "99":
			break;
		default:
			System.out.println("--- Try Again. --- \n\n");
		}
	}
    
    private void displayDoneeManagementMenu(){
        String menuOption = "";
        
        do{
            System.out.println("================================");
            System.out.println("||     DONEE MANAGEMENT     ||");
            System.out.println("================================");
            System.out.println("||   1 ADD DONEE            ||");
            System.out.println("||   2 DISPLAY DONEE        ||");
            System.out.println("||  3 DELETE DONEE          ||");
            //System.out.println("||  4 GENERATE REPORT      ||");
            System.out.println("||   0 BACK TO MAIN MENU    ||");
            System.out.println("================================");
            System.out.println("================================");
            
            System.out.println("Option: ");
            menuOption = KeyboardInput.getInputFromUser();
            System.out.println();
            
            DoneeManagementAction(menuOption);
        }while (!menuOption.equals("0"));
    }
    
    private void DoneeManagementAction(String menuOption){
        switch(menuOption){
            case "1":
                DoneeManagement.addDonee(df.getDonee());
                break;
            case "2":
                DoneeManagement.displayDonee(df.getDonee());
                break;
            case "0":
                break;
           default:
			System.out.println("--- Try Again. --- \n\n");
        }
    }
}
