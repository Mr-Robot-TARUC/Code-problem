package adt;

import entity.Donee;
import java.util.Queue;
import java.util.*;

public interface DoneeInterface<T> {

    //public void enqueue(T newEntry); //add a new entry to the rear
    public boolean offer(T newEntry);

    public T dequeue();//remove and return the entry at the front

    public T peek();//retrieve front
    
    public T peekLast();//retrieve last

    public boolean isEmpty();

    public boolean isFull();

    public void clear();

    public boolean contains(T anEntry);// Detect whether the entry exist in the queue.

    public String toString();

}
