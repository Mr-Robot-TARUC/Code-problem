package adt;

import entity.Donee;

public class DoneeList<T extends Comparable<T>> implements DoneeInterface<T> {

    private T[] array;
    private Node front;
    private Node back;
    private int count;
  //  private int currentNode;
    private static final int DEFAULT_CAPACITY = 100;
    
    public DoneeList(){
        this(DEFAULT_CAPACITY);
    }
    
    public DoneeList(int initialCapacity){
       // currentNode=0;
        array = (T[]) new Comparable[initialCapacity];
    }
    
    @Override
    public boolean offer(T newEntry) {
        Node currentNode = back;
        
        while(currentNode != null){
            if(newEntry.compareTo(currentNode.data) ==0)
                return false;
            currentNode = currentNode.next;
        }
        Node newNode = new Node(newEntry);
        if(isEmpty())
            front = newNode;
        else
            back.next=newNode;
        back=newNode;
        count++;
        
        return true;
    }

    @Override
    public T dequeue() {
        T first =null;
        if(!isEmpty()){
            first =front.data;
            front=front.next;
            
            if(front == null){
                back=null;
            }
            count--;
        }
        return first;
    }

    @Override
    public T peek() {
        if(!isEmpty())
            return front.data ;
        return null;
       
    }
    
    @Override
    public T peekLast(){
        if(!isEmpty())
            return back.data ;
        return null;
    }

    @Override
    public boolean isEmpty() {
        return(front == null && back == null);
    }

    @Override
    public boolean isFull() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void clear() {
        front=null;
        back=null;
    }

    @Override
    public boolean contains(T anEntry) {
       boolean found=false;
       for(int index=0;!found&&(index<count);index++){
           if(anEntry.equals(array[index])){
               found=true;
           }
       }
       return found;
    }

    private class Node {
        private T data;
        private Node next;

        public Node(T data) {
            this.data = data;
            this.next = next;
        }
        
        private Node(T data, Node next){
            this.data= data;
            this.next = next;
        }
    }

}
