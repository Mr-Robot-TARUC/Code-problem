package adt;

import adt.DoneeInterface;
import java.util.NoSuchElementException;

public class LinkQueue<T extends Comparable<T>> implements DoneeInterface<T> {

    private T[] array;
    private Node front;
    private Node back;
    private int count;
    private static final int DEFAULT_CAPACITY = 100;

    public LinkQueue() {
        this(DEFAULT_CAPACITY);
    }

    public LinkQueue(int initialCapacity) {
        // currentNode=0;
        array = (T[]) new Comparable[initialCapacity];
    }

    @Override
    public boolean offer(T newEntry) {
        Node newNode = new Node(newEntry);
        Node nodeBefore = null;
        Node currentNode = back;
        while (currentNode != null && newEntry.compareTo(currentNode.data) > 0) {
            nodeBefore = currentNode;
            currentNode = back.next;
        }

        if (isEmpty() || (nodeBefore == null)) {
            newNode.next = currentNode;
            nodeBefore.next = newNode;
        }
        count++;
        return true;
    }

    @Override
    public T dequeue() {
        T first = null;
        // if (!isEmpty()) throw new NoSuchElementException("Queue underflow");
        if (!isEmpty()) {
            first = front.data;
            front = front.next;
            count--;
        }
        if (!isEmpty()) {
            back = null;
        }
        return front.data;
    }

    @Override
    public T peek() {
        if (isEmpty()) {
            throw new NoSuchElementException("Queue underflow");
        }
        return front.data;
    }

    @Override
    public T peekLast() {
        if (isEmpty()) {
            throw new NoSuchElementException("Queue underflow");
        }
        return back.data;
    }

    @Override
    public boolean isEmpty() {
        return (count == 0);
    }

    @Override
    public boolean isFull() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public final void clear() {
        front = null;
        back = null;
        count = 0;
    }

    @Override
    public boolean contains(T anEntry) {
        boolean found = false;
        Node tempNode = front;

        while (!found && (tempNode != null)) {
            if (anEntry.compareTo(tempNode.data) <= 0) {
                found = true;
            } else {
                tempNode = tempNode.next;
            }
        }
        if (tempNode != null && tempNode.data.equals(anEntry)) {
            return true;
        } else {
            return false;
        }
    }

    private class Node {

        private T data;
        private Node next;

        public Node(T data) {
            this.data = data;
            this.next = next;
        }

        private Node(T data, Node next) {
            this.data = data;
            this.next = next;
        }
    }

}
