package test;

import entity.Donee;
import entity.Food;
import java.util.*;
public class linkArray{
    // Java program to add elements
// to a LinkedList

	public static void main(String args[])
	{
		/*LinkedList<String> ll = new LinkedList<>();
	
		ll.add("Geeks");
		ll.add("Geeks");
		ll.add(1, "For"); */
                
               ArrayList<Donee> donee = new ArrayList<Donee>();
        donee.add(new Food(1001, "Joy","Rice 5KG and oil 5 KG","2 Packages, 1 Bucket"));
        donee.add(new Food(1002, "Jim","Rice 5KG and oil 5 KG","2 Packages, 1 Bucket"));

        
       /* AraryList<Food> food = new ArrayList<Food>();
        food.add(new Food("abc",12)); */
        
	
		System.out.println("=================================================");
                System.out.println("ID ===Name  ==Tel     ==== FoodN       === FoodQ=");
                System.out.println(donee);
               
                System.out.println("=================================================");
	}
}

