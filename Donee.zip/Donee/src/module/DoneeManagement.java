package module;

import adt.DoneeInterface;
import entity.Donee;
import entity.Food;
import util.KeyboardInput;
import java.util.*;

public class DoneeManagement {
  
    private static int DoneeId =1000;
    
    public static void loadDoneeData(DoneeInterface<Donee> doneeArray){
          //create arrayList (Donee)
               /* Donee doneeA = new Food(DoneeId++,"Joy","Rice 5KG and oil 5 KG","2 Packages and 1 Bucket");
                doneeList.offer(doneeA); */
        ArrayList<Donee> donee = new ArrayList<Donee>();
        donee.add(new Food(DoneeId++, "Joy","Rice 5KG and oil 5 KG","2 Packages, 1 Bucket"));
        donee.add(new Food(DoneeId++, "Jim","Rice 5KG and oil 5 KG","2 Packages, 1 Bucket"));
            /*  
               Donee[] donee = new Donee[1];
               donee[0] = new Food(1001, "Joy","Rice 5KG and oil 5 KG","2 Packages, 1 Bucket");
               donee[1] = new Food(1002, "Jim","Rice 5KG and oil 5 KG","2 Packages, 1 Bucket"); */
           
    }
    //display
    public static void displayDonee(DoneeInterface<Donee> doneeArray){
        System.out.println("Donee List: ");
        System.out.println("--------------------------------------------------");
        System.out.println(doneeArray);
        System.out.println("--------------------------------------------------");
    }
    
    //add
    public static void addDonee(DoneeInterface<Donee> doneeList){
        Donee donee = null;
        String option = null;
        //String foodName2;
        //boolean answer; 
        
        System.out.println("===================");
        System.out.println("== Add New Donee ==");
        System.out.println("===================");
        
        System.out.print("Donee Name : ");
        String doneeName = KeyboardInput.getInputFromUser();
        System.out.println();
        
        System.out.print("Food Name : ");
        String foodName = KeyboardInput.getInputFromUser();
        System.out.println();
        
        System.out.print("Quntity : ");
        String foodQty = KeyboardInput.getInputFromUser();
        System.out.println();
        
       donee = new Food(DoneeId++, doneeName,foodName, foodQty);
     
        if(donee == null){
            doneeList.offer(donee);
        }
        
    
     }
        
}

        
    

