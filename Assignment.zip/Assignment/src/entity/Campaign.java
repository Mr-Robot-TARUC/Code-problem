package entity;

import adt.ListInterface;

public class Campaign implements Comparable<Campaign>{
	private int ID;
	private String campaignName;
	private String EventName;
	private String Date;
	private String Location;
	private String Organizer;
	private ListInterface<Campaign> campaigns;
	
	public Campaign(String campaignName) {
		this.campaignName = campaignName;
	}
	public ListInterface<Campaign> getCampaigns() {
		return campaigns;
	}
	public void setCampaigns(ListInterface<Campaign> campaigns) {
		this.campaigns = campaigns;
	}
	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}
	
	public Campaign(int ID, String EventName, String Date, String Location, String Organizer) {
		this.ID = ID;
		this.EventName = EventName;
		this.Date = Date;
		this.Location = Location;
		this.Organizer = Organizer;
	}

	@Override
	public int compareTo(Campaign campaign) {
		return this.ID - campaign.getID();
	}

	public int getID() {
		return ID;
	}
	public void setID(int ID) {
		this.ID = ID;
	}
	public String getEventName() {
		return EventName;
	}
	public void setEventName(String EventName) {
		this.EventName = EventName;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String Date) {
		this.Date = Date;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String Location) {
		this.Location = Location;
	}
	public String getOrganizer() {
		return Organizer;
	}
	public void setOrganizer(String Organizer) {
		this.Organizer = Organizer;
	}
	@Override
	public String toString() {
		return "Campaign [ID=" + ID + ", EventName=" + EventName + ", Date=" + Date + ", Location=" + Location
				+ ", Organizer=" + Organizer + ", campaigns=" + campaigns.getNumberOfEntries() + "]";
	}
	
}
