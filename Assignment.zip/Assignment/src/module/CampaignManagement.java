package module;

import java.text.SimpleDateFormat;
import java.util.Date;
import adt.ListInterface;
import entity.Campaign;

public class CampaignManagement {
	private static int campaignId = 1000;
	//static Date thisDate = new Date();
	//static SimpleDateFormat dateForm = new SimpleDateFormat("MM/dd/YY");
	
	/**
	 * Loading preset data
	 *
	 * @param campaignList campaignList to update
	 */
	public static void loadCampaignData(ListInterface<Campaign> campaignList) {
		//Campaign campaignA = new Campaign(campaignId++, "Life of Giving", dateForm.format(thisDate), "Kampar", "Cocola Company");
		//Campaign campaignB = new Campaign(campaignId++, "Worthy Wellness", dateForm.format(thisDate), "Ipoh", "Apple Company");
		Campaign campaignA = new Campaign(campaignId++, "CareClub", "08/18/21", "Kuala Lumpur", "Huawei Company");
		Campaign campaignB = new Campaign(campaignId++, "CareClub", "08/18/21", "Kuala Lumpur", "Huawei Company");
		Campaign campaignC = new Campaign(campaignId++, "CareClub", "08/18/21", "Kuala Lumpur", "Huawei Company");

		campaignList.add(campaignA);
		campaignList.add(campaignB);
		campaignList.add(campaignC);
	}
	
	/**
	 * Display campaign
	 *
	 * @param campaignList campaignList to update
	 */
	public static void displayCampaigns(ListInterface<Campaign> campaignList) {
		System.out.println("Campaign List: \n" + campaignList);
	}
}
