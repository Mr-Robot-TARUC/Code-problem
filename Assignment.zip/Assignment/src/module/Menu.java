package module;

public class Menu {
	public void Header() {
		System.out.println("+==================================+");
		System.out.println("|          Welcome to our          |");
		System.out.println("|           Food Bank !!           |");
		System.out.println("+==================================+");
	}
	
	public void displayMenu() {
		System.out.println("\nPlease make a selection");
		System.out.println("-----------------------");
		System.out.println("1. Campaign Display");
		System.out.println("2. Campaign Search");
		System.out.println("3. Campaign Edit");
		System.out.println("4. Campaign Add");
		System.out.println("5. Campaign Remove");
		System.out.println("0. Exit");
		
		System.out.print("\nEnter your choice: ");
	}
}
