package client;

import java.util.Scanner;
import module.CampaignManagement;
import adt.SortedArrayList;
import entity.Campaign;
import module.Menu;

public class StartApplication {
	private Campaign campaign;
	public static void main(String[] args) {
		var startApplication = new StartApplication();
		startApplication.initializeApplication();
		System.out.println("+==================================+");
		System.out.println("|          Welcome to our          |");
		System.out.println("|           Food Bank !!           |");
		System.out.println("+==================================+");
		System.out.println();
		startApplication.displayMainMenu();
	}
	
	private void initializeApplication() {
		campaign = new Campaign("Our Campaign");
		campaign.setCampaigns(new SortedArrayList<>());
		
		CampaignManagement.loadCampaignData(campaign.getCampaigns());
	}
	
	private void displayMainMenu() {
		int choice = -1;
		Scanner scn = new Scanner(System.in);
		
		while (choice != 0) {
			try {
				System.out.println("*******************************");
				System.out.println("* 1. Donee Management         *");
				System.out.println("* 2. Donor Management         *");
				System.out.println("* 3. Campaign Management      *");
				System.out.println("* 4. Sponsorship Maintenance  *");
				System.out.println("* 0. Exit                     *");
				System.out.println("*******************************");
				
				System.out.print("Enter your choice: ");
				choice = scn.nextInt();
				
				switch (choice) {
				case 0:
					System.out.println("Thank you and welcome back to our food bank!");
					break;
				case 1:
					System.out.println("Waiting 1");
					break;
				case 2:
					System.out.println("Waiting 2");
					break;
				case 3:
					displayCampaignManagementSubMenu();
					break;
				case 4:
					System.out.println("Waiting 4");
					break;
				default:
					System.out.println("Please select (1-4) or 0 for exit! \n");
					break;
				}
			} catch (Exception e) {
				System.out.println("No such option. Please try again.... \n");
				scn.next();
			}
		}
	}
	
	private void displayCampaignManagementSubMenu() {
		int choice = -1;
		Scanner scn = new Scanner(System.in);
		
		while (choice != 0) {
			try {
				System.out.println("\nPlease make a selection");
				System.out.println("-----------------------");
				System.out.println("1. Campaign Display");
				System.out.println("2. Campaign Search");
				System.out.println("3. Campaign Edit");
				System.out.println("4. Campaign Add");
				System.out.println("5. Campaign Remove");
				System.out.println("0. Back");
				
				System.out.print("Enter your choice: ");
				choice = scn.nextInt();
				
				switch (choice) {
				case 0:
					System.out.println();
					break;
				case 1:
					CampaignManagement.displayCampaigns(campaign.getCampaigns());
					break;
				case 2:
					System.out.println("testing 2");
					break;
				case 3:
					System.out.println("testing 3");
					break;
				case 4:
					System.out.println("testing 4");
					break;
				case 5:
					System.out.println("testing 5");
					break;
				default:
					System.out.println("Please select (1-4) or 0 for exit! \n");
					break;
				}
			} catch (Exception e) {
				System.out.println("No such option. Please try again.... \n");
				scn.next();
			}
		}
	}
}
